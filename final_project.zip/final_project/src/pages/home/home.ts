import { Component } from '@angular/core';
import { NavController, AlertController } from 'ionic-angular';



@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {

  //public ages = [];
 // listAgeText;
  ageText = 0;
  editText;

  constructor( public navCtrl: NavController, public alertCtrl: AlertController) {

    //this.ages = this.convertProvider.getConverted();
  }

  dogYears(text, ) {

    if (text == 1) {
      this.ageText = 15;

    } else if (text == 2 ){
      this.ageText = text * 9;

    } else if (text > 2){
      this.ageText =  text * 5;
    }

    //this.convertProvider.addConverted(this.ageText);
    this.showAlert();
  }

  showAlert() {
    const alert = this.alertCtrl.create({
      title: 'Age Converted!',
      subTitle: 'Your dog is ' + this.ageText + 'years old',
      buttons: ['OK']
    });
    alert.present();
  }





}
