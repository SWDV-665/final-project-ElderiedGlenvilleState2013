import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-contact',
  templateUrl: 'contact.html'
})
export class ContactPage {

  userPhoneNumber = 0;
  userName = "";
  constructor(public navCtrl: NavController, ) {

    

  }

}
